export const ApiUrls : any ={

    signUpApi : 'https://retoolapi.dev/BCxzLm/signup'

}