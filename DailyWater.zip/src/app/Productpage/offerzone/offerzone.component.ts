import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-offerzone',
  templateUrl: './offerzone.component.html',
  styleUrls: ['./offerzone.component.scss']
})
export class OfferzoneComponent {
  // constructor(public dialog: MatDialog) {}

  // openDialog(enterAnimationDuration: string, exitAnimationDuration: string): void {
  //   this.dialog.open(, {
  //     width: '250px',
  //     enterAnimationDuration,
  //     exitAnimationDuration,
  //   });
  // }

}
