import { Component } from '@angular/core';

@Component({
  selector: 'app-staff-attendence',
  templateUrl: './staff-attendence.component.html',
  styleUrls: ['./staff-attendence.component.scss']
})
export class StaffAttendenceComponent {

}
