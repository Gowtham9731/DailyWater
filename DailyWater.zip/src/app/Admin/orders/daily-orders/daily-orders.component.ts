import { Component } from '@angular/core';

@Component({
  selector: 'app-daily-orders',
  templateUrl: './daily-orders.component.html',
  styleUrls: ['./daily-orders.component.scss']
})
export class DailyOrdersComponent {
quantity: any;
amount: any;
address: any;
status: any;
proname: any;
delDate: any;
delStatus: any;

}
