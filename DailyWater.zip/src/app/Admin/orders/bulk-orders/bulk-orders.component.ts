import { Component } from '@angular/core';

@Component({
  selector: 'app-bulk-orders',
  templateUrl: './bulk-orders.component.html',
  styleUrls: ['./bulk-orders.component.scss']
})
export class BulkOrdersComponent {

}
