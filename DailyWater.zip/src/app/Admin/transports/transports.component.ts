import { Component, ViewChild } from '@angular/core';
// import { MatAccordion } from '@angular/material/expansion';

@Component({
  selector: 'app-transports',
  templateUrl: './transports.component.html',
  styleUrls: ['./transports.component.scss']
})
export class TransportsComponent {


 
}
