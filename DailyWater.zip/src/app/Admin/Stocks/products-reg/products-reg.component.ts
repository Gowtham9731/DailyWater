import { Component } from '@angular/core';

@Component({
  selector: 'app-products-reg',
  templateUrl: './products-reg.component.html',
  styleUrls: ['./products-reg.component.scss'],
  
})
export class ProductsRegComponent {

}
